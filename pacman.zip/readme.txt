Programmed by:
Oz Hayun: 209368695
Nave Maor: 208523605


Bonuses:
1) Added an option for playing with colors or without colors in the game settings menu.
2) Added on option for changing the pacman movement speed in the game settings menu.
3) Implimented an algorithm that can find the shortest path between two points(mindistance)

